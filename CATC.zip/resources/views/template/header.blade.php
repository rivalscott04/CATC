<div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i
                                class="fa fa-bars"></i> </a>
                    </div>
                    <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <span class="m-r-sm text-muted welcome-message">Selamat Datang di Sistem Informasi Presensi</span>
                        </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                                <i class="fa fa-th-list"></i> 
                            </a>
                            <ul class="dropdown-menu dropdown-alerts">
                                <li>
                                    <a href="profil" class="dropdown-item">
                                        <div>
                                            <i class="fa fa-user fa-fw"></i> Profil
                                        </div>
                                    </a>
                                </li>
                                <li class="dropdown-divider"></li>
                                <li>
                                    <a href="/ganti_password" class="dropdown-item">
                                        <div>
                                            <i class="fa fa-key fa-fw"></i> Ganti Password
                                        </div>
                                    </a>
                                </li>
                                <li class="dropdown-divider"></li>
                                <li>
                                    <a href="logout">
                                        <i class="fa fa-sign-out"></i> Keluar
                                    </a>
                                </li>
                                <li class="dropdown-divider"></li>
                            </ul>
                        </li>


                        {{-- <li>
                            <a href="logout">
                                <i class="fa fa-sign-out"></i> Keluar
                            </a>
                        </li> --}}
                    </ul>

                </nav>
            </div>