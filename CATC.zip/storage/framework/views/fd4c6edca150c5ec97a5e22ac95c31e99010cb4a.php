<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>INSPINIA | Dashboard v.2</title>

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


</head>

<body>
    <div id="wrapper">
        <?php echo $__env->make('template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="page-wrapper" class="gray-bg">
            <?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="wrapper wrapper-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <div class="footer">
                <div class="float-right">
                    10GB of <strong>250GB</strong> Free.
                </div>
                <div>
                    <strong>Copyright</strong> Example Company &copy; 2014-2018
                </div>
            </div>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src=<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>></script>
    <script src=<?php echo e(asset('js/popper.min.js')); ?>></script>
    <script src=<?php echo e(asset('js/bootstrap.js')); ?>></script>
    <script src=<?php echo e(asset('js/plugins/metisMenu/jquery.metisMenu.js')); ?>></script>
    <script src=<?php echo e(asset('js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>></script>

    <!-- Custom and plugin javascript -->
    <script src=<?php echo e(asset('js/inspinia.js')); ?>></script>
    <script src=<?php echo e(asset('js/plugins/pace/pace.min.js')); ?>></script>

    <!-- jQuery UI -->
    <script src=<?php echo e(asset('js/plugins/jquery-ui/jquery-ui.min.js')); ?>></script>

    <!-- Flot -->
    <script src=<?php echo e(asset('js/plugins/flot/jquery.flot.js')); ?>></script>
    <script src=<?php echo e(asset('js/plugins/flot/jquery.flot.tooltip.min.js')); ?>></script>
    <script src=<?php echo e(asset('js/plugins/flot/jquery.flot.resize.js')); ?>></script>
    <script src=<?php echo e(asset('js/plugins/flot/jquery.flot.pie.js')); ?>></script>
    <script src=<?php echo e(asset('js/plugins/flot/jquery.flot.time.js')); ?>></script>

    <!-- Flot demo data -->
    <script src=<?php echo e(asset('js/demo/flot-demo.js')); ?>></script>


    <!-- ChartJS-->
    <script src=<?php echo e(asset('js/plugins/chartJs/Chart.min.js')); ?>></script>
    <script src=<?php echo e(asset('js/demo/chartjs-demo.js')); ?>></script>

    
    
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            console.log("ready!");
            $(document).ready(function() {
                $('.js-example-basic-single').select2();
            });
        });
    </script>

</body>

</html>
<?php /**PATH D:\Project\Si_Presensi\resources\views/app.blade.php ENDPATH**/ ?>